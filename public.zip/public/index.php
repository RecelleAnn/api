<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
require '../src/vendor/autoload.php';
$app = new \Slim\App;
//endpoint get greeting
$app->get('/DMMMSUOrgStructure', function (Request $request, Response
$response, array $args) {

    $test = array(array("DMMMSU" => "OrgStructure"), array("President" => "Dr. Jaime I. Manuel Jr."), array("University Secretary" => "Dr. Antonio O. Ogbinar"));
    echo json_encode($test);
    $test = array(array("Vice President Academic Affairs" => "Dr. Elsie M. Pacho"), array("OIC-Director, Instruction" => "Prof. Laiza T. Astodillo"), array("Director, Student Affairs and Services" => "Dr. Shalimar L. Navalta"), array("Director, Sports" => "Dr. Paulo Jan F. Samson"),
    array("Director, Cultural Affairs" => "Prof. Irene N. Gomez"), array("Director, National Service Training Program" => "Dr. Loida M. Faller"), array("Director, Library Services and Development" => "Dr. Sonia B. Siago"), array("Director, Student Admission and Records" => "Dr. Valoree M. Salamanca"), 
    array("Director, Alumni Affairs" => "Dr. Lher Verell S. Palabay"), array("Director, Internationalization, Linkages, and ETEEAP" => "Dr. Jesus Rafael B. Jarata"),);
    echo json_encode($test);
    $test = array(array ("Vice President Research and Extension" => "Dr. Angelina T. Gonzales"), array("Director, Research" => "Prof. Keneth G. Bayani"), array("Director, Extension" => "Prof. Emerita D. Galiste"));
    echo json_encode($test);
    $test = array(array ("Vice President Administration" => "Dr. Antonio O. Ogbinar"), array("Director, Administrative Services" => "Atty. Kristine Gay B. Balanag"), array("Director, Auxiliary Services" => "Dr. Florendo O. Damasco, Jr."), array("Director, Finance Services" => "Ms. Placida E. De Guzman"),
    array("Director, Medical Services" => "Dr. Ma. Consuelo W. Alcantara"), array("Director, Internal Quality Assurance System" => "Dr. Angelita J. Prado"));
    echo json_encode($test);
    $test = array(array("Vice President, Planning and Resource Development" => "Dr. Priscilo P. Fontanilla"), array("Director, Management Information System" => "Dr. Stephan Kupsch"), array("Director, Business Affairs" => "Prof. Melchor D. Salom"), 
    array("Director, Planning and Development" => "Prof. Lilito D. Gavina"), array("Director, Resource Development and GAD Focal Person" => "Dr. Sherlyn Marie D. Nitura"));
    echo json_encode($test);
    $test = array(array("President" => "Dr. Jaime I. Manuel Jr."), array("Chancellor, North La Union Campus" => "Dr. Junifer Rey E. Tabafunda"), array("Chancellor, Mid La Union Campus" => "Dr. Eduardo C. Corpuz"), array("Chancellor, South La Union Campus" => "Dr. Joanne C. Rivera"),
    array("Executive Director Open University System" => "Dr. Cristita G. Guerra"), array("Executive Director Sericulture Research and Development Institute" => "Dr. Cristeta F. Gapuz"), 
    array("Executive Director National Apiculture Research Training and Development Institute" => "Dr. Gregory B. Viste"));
    echo json_encode($test);

});
$app->run();
?>